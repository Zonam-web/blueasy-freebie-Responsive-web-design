jQuery(function ($) {
  $(window).on("load", function () {
    function getPics() { }

    const imgs = document.querySelectorAll(".gallery img");
    const fullPage = document.querySelector("#fullpage");

    imgs.forEach((img) => {
      img.addEventListener("click", function () {
        fullPage.style.backgroundImage = "url(" + img.src + ")";
        fullPage.style.display = "block";
      });
    });

    wow = new WOW(
      //   {
      //   boxClass:     'wow',      // default
      //   animateClass: 'animated', // default
      //   offset:       0,          // default
      //   mobile:       true,       // default
      //   live:         true        // default
      // }
    )
    wow.init();
  });



  //faq js
  var speed = '500ms';
    $('.accordionItem .accordionTitle').on('click', function () {
        $(this).next().slideToggle(speed)
                    // selects all other answers and slides up any open answer
                    .siblings('.accordionItem .accordionContent').slideUp();
                    //grab angle-down icons
                    var angleicon = $(this).children('i');
                     // remove Rotate class from all angleicon except the active
                    $('i').not(angleicon).removeClass('rotate');
                    //toggle rotate class
                    angleicon.toggleClass('rotate');
    });
});



// isotope js

$('.portfolio-item').isotope({
  // options
  itemSelector: '.item',
  layoutMode: 'fitRows'
});

$('.portfolio-nav ul li a').click(function () {
  $('.portfolio-nav ul li a').removeClass('home');
  $(this).addClass('home');


  var selector = $(this).attr('data-filter');
  $('.portfolio-item').isotope({
      filter: selector
  });
  return false;
});




